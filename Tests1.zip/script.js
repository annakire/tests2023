

//banka ... jautajumu kopumu
const jautajumi=[
  {
    jautajums:"Kas ir galvenais zemes satelits?",
    atbilde:"Meness"
  },
{
  jautajums:"Cik ir 2+2",
  atbilde:"4"
},
  {
    jautajums:"Ka sauc lielako okeanu?",
    atbilde:"Klusais okeans"
  }
]

//maigihie  ar ko sasaist'it js un html
const jautajumsElements=document.getElementById("jautajums");
const atbildeInput=document.getElementById("atbilde");
const iesniegtButton=document.getElementById("iesniegt");

let esosaisJautajumsIndex=0;
// funkcija ar merki paradit jautajumu
function paradiJautajumu(){
  jautajumsElements.textContent=jautajumi[esosaisJautajumsIndex].jautajums
}


//funkcija ...parbaudit atbildi
function parbaudiAtbildi(){
 const lietotajaAtbilde=atbildeInput.value.trim().toLowerCase();
  const pareizaAtbilde=jautajumi[esosaisJautajumsIndex].atbilde.toLowerCase();
  
if(lietotajaAtbilde === pareizaAtbilde){
  alert("Pareizi");
}else{
  alert("Nepareizi");
}
esosaisJautajumsIndex++;
  if(esosaisJautajumsIndex<jautajumi.lenght){
    paradiJautajumu();
    atbildeInput.value="";
  }else{
    jautajumsElements.textContent="spele beigusies!";
    atbildeInput.disable=true;
    iesniegtButton.disabled=true;
  }

}
//klaus'it'ajs....
paradiJautajumu();
iesniegtButton.addEventListener("click",parbauditAtbildi);
